# Standard library
import sys

# Packages
from jinja2 import Environment, FileSystemLoader


env = Environment(loader=FileSystemLoader('templates'))
image_template = env.get_template('image_template.html')


def image_template(url, alt, width, height):
    """
    Generate image markup
    """

    return image_template.render(
        url=url,
        alt=alt,
        width=width,
        height=height
    )


sys.modules[__name__] = image_template
